TopCoder
========

Repository for solutions to www.topcoder.com problems, written in c++  
https://github.com/shivawu/topcoder-greed plugin was used to generate solution templates
