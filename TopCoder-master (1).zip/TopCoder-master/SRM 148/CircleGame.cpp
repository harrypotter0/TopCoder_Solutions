#include <cstdio>
#include <cmath>
#include <cstring>
#include <ctime>
#include <iostream>
#include <algorithm>
#include <set>
#include <vector>
#include <sstream>
#include <typeinfo>
#include <fstream>

using namespace std;

class CircleGame {
    public:
    int cardsLeft(string deck) {
        vector<int> valueDeck = parseDeck<int>(deck);
        size_t size {valueDeck.size()};
        bool changed {true};

        if (size > 1)
        {
            while (changed)
            {
                changed = false;
                if (size > 1)
                {
                    for (size_t i = 0; i < size - 1; ++i)
                    {
                        if (valueDeck[i] + valueDeck[i+1] == 13)
                        {
                            valueDeck[i] = 0;
                            valueDeck[i+1] = 0;
                            changed = true;
                        }
                    }                
                    deleteValues(valueDeck, 0);
                    size = valueDeck.size();
                }
            }            

            size = valueDeck.size();
            changed = true;
            size_t i = 0;

            while (changed && i < size)
            {
                changed = false;
                if (valueDeck[i] + valueDeck[size-1-i] == 13)
                {
                    valueDeck[i] = 0;
                    valueDeck[size-1-i] = 0;
                    changed = true;
                }
                ++i;
            } 

            deleteValues(valueDeck, 0);        
        }

        return valueDeck.size();
    }

    template <typename T>
    void inline printVector(const vector<T>& v)
    {
        for (T val : v)
        {
            cout << val << " ";
        }
        cout << endl;
    }
    template <typename T>
    void inline deleteValues(vector<T>& v, const T val)
    {
        v.erase(remove_if(v.begin(), v.end(), 
                            [&val](T elem){
                                return elem == val;
                            }),
                v.end());        
    }

    template <typename T>
    vector<T> inline parseDeck(const string& deck)
    {
        vector<T> tmpDeck {};
        for (char c : deck)
        {
            if (c != 'K')
            {
                int value {};
                switch (c)
                {
                    case 'A' : value = 1; break;
                    case 'Q' : value = 12; break;
                    case 'J' : value = 11; break;
                    case 'T' : value = 10; break;
                    case '9' :
                    case '8' :
                    case '7' :
                    case '6' :
                    case '5' :
                    case '4' :
                    case '3' :
                    case '2' : value = c - '0'; break;
                }
                
                tmpDeck.push_back(value);
            }
        }

        return tmpDeck;
    }
};

// CUT begin
ifstream data("CircleGame.sample");

string next_line() {
    string s;
    getline(data, s);
    return s;
}

template <typename T> void from_stream(T &t) {
    stringstream ss(next_line());
    ss >> t;
}

void from_stream(string &s) {
    s = next_line();
}

template <typename T>
string to_string(T t) {
    stringstream s;
    s << t;
    return s.str();
}

string to_string(string t) {
    return "\"" + t + "\"";
}

bool do_test(string deck, int __expected) {
    time_t startClock = clock();
    CircleGame *instance = new CircleGame();
    int __result = instance->cardsLeft(deck);
    double elapsed = (double)(clock() - startClock) / CLOCKS_PER_SEC;
    delete instance;

    if (__result == __expected) {
        cout << "PASSED!" << " (" << elapsed << " seconds)" << endl;
        return true;
    }
    else {
        cout << "FAILED!" << " (" << elapsed << " seconds)" << endl;
        cout << "           Expected: " << to_string(__expected) << endl;
        cout << "           Received: " << to_string(__result) << endl;
        return false;
    }
}

int run_test(bool mainProcess, const set<int> &case_set, const string command) {
    int cases = 0, passed = 0;
    while (true) {
        if (next_line().find("--") != 0)
            break;
        string deck;
        from_stream(deck);
        next_line();
        int __answer;
        from_stream(__answer);

        cases++;
        if (case_set.size() > 0 && case_set.find(cases - 1) == case_set.end())
            continue;

        cout << "  Testcase #" << cases - 1 << " ... ";
        if ( do_test(deck, __answer)) {
            passed++;
        }
    }
    if (mainProcess) {
        cout << endl << "Passed : " << passed << "/" << cases << " cases" << endl;
        int T = time(NULL) - 1399137968;
        double PT = T / 60.0, TT = 75.0;
        cout << "Time   : " << T / 60 << " minutes " << T % 60 << " secs" << endl;
        cout << "Score  : " << 250 * (0.3 + (0.7 * TT * TT) / (10.0 * PT * PT + TT * TT)) << " points" << endl;
    }
    return 0;
}

int main(int argc, char *argv[]) {
    cout.setf(ios::fixed, ios::floatfield);
    cout.precision(2);
    set<int> cases;
    bool mainProcess = true;
    for (int i = 1; i < argc; ++i) {
        if ( string(argv[i]) == "-") {
            mainProcess = false;
        } else {
            cases.insert(atoi(argv[i]));
        }
    }
    if (mainProcess) {
        cout << "CircleGame (250 Points)" << endl << endl;
    }
    return run_test(mainProcess, cases, argv[0]);
}
// CUT end
